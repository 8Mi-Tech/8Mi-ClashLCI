#!/bin/bash
#8Mi-ClashControl <Powered By Clash>
export http_proxy="https://127.0.0.1:7890"
export https_proxy=$http_proxy
export ftp_proxy=$http_proxy
export SOCKS_SERVER="https://127.0.0.1:7891"
export no_proxy="localhost, 127.0.0.1, ::1"
